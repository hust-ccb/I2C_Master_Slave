/*
 * "Hello World" example.
 *
 * This example prints 'Hello from Nios II' to the STDOUT stream. It runs on
 * the Nios II 'standard', 'full_featured', 'fast', and 'low_cost' example
 * designs. It runs with or without the MicroC/OS-II RTOS and requires a STDOUT
 * device in your system's hardware.
 * The memory footprint of this hosted application is ~69 kbytes by default
 * using the standard reference design.
 *
 * For a reduced footprint version of this template, and an explanation of how
 * to reduce the memory footprint for a given application, see the
 * "small_hello_world" template.
 *
 */

#include <stdio.h>
#include "system.h"
#include "unistd.h"
#include "oc_i2c.h"

uint16_t rddata = 0;
uint8_t data = 0;
int main()
{
  printf("Hello from Nios II!\n");

  InitI2C(I2C_MASTER_BASE, 400000, 0);
  usleep(1000);

  I2CWriteOneReg(I2C_MASTER_BASE, 0x3c, 0x15, 0x01, 0x77);
  I2CWriteOneReg(I2C_MASTER_BASE, 0x3c, 0x17, 0x01, 0x88);
  I2CWrite(I2C_MASTER_BASE, 0x3c, 0x10, 0x02, 0x5566);

  rddata = I2CRead(I2C_MASTER_BASE, 0x3c, 0x14, 0x02);
  printf("%x\n",rddata);

  data = I2CReadOneReg(I2C_MASTER_BASE, 0x3c, 0x11, 0x01);
  printf("%x\n",data);
  return 0;
}
