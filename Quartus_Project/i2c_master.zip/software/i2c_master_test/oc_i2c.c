#include "system.h"
#include "oc_i2c_regs.h"
#include "oc_i2c.h"
#include "alt_types.h"


void I2CWaitTIP(uint32_t base);


void InitI2C(uint32_t base, uint32_t freq, uint8_t IEN)
{
	uint32_t prescale;
	// Calculate the prescale value
	prescale = ALT_CPU_FREQ / (5*freq) - 1;
	// Setup prescaler for the freq of SCL with sysclk of ALT_CPU_FREQ
	IOWR_OC_I2C_PRERLO(base, prescale & 0xff);
	IOWR_OC_I2C_PRERHI(base, prescale >> 8);
	// Enable core
	if (IEN == 1) // Enable interrupt
			{
		IOWR_OC_I2C_CTR(base, 0xC0);
	} else // Enable core while disable interrupt
	{
		IOWR_OC_I2C_CTR(base, 0x80);
	}
}

void I2CWaitTIP(uint32_t base)
{
	while ((IORD_OC_I2C_SR(base) & OC_I2C_SR_TIP_MSK) > 0)
	{
	}
}


void I2CWriteOneReg(uint32_t base, uint8_t address, uint8_t reg, uint8_t num, uint8_t data)
{
	// Wait for the completion of transfer
	I2CWaitTIP(base);

	// write address of I2C slave device
	// and generate START & WR command
	IOWR_OC_I2C_TXR(base, address<<1);
	IOWR_OC_I2C_CR(base, OC_I2C_CR_STA_MSK | OC_I2C_CR_WR_MSK);
	I2CWaitTIP(base);

	// write register address
	IOWR_OC_I2C_TXR(base, reg);
	IOWR_OC_I2C_CR(base, OC_I2C_CR_WR_MSK);
	I2CWaitTIP(base);

	//дһ����ʾ���ݳ��ȵ����ݽ�ȥ 2021/3/17/ccb
	IOWR_OC_I2C_TXR(base, num);
	IOWR_OC_I2C_CR(base, OC_I2C_CR_WR_MSK);
	I2CWaitTIP(base);

	// write data with STOP signal
	IOWR_OC_I2C_TXR(base, data);
	IOWR_OC_I2C_CR(base, OC_I2C_CR_WR_MSK | OC_I2C_CR_STO_MSK);
	I2CWaitTIP(base);
}


void I2CWrite(uint32_t base, uint8_t address, uint8_t reg, uint8_t num, uint16_t data)
{
	// Wait for the completion of transfer
	I2CWaitTIP(base);

	// write address of I2C slave device
	// and generate START & WR command
	IOWR_OC_I2C_TXR(base, address<<1);
	IOWR_OC_I2C_CR(base, OC_I2C_CR_STA_MSK | OC_I2C_CR_WR_MSK);
	I2CWaitTIP(base);

	// write register address
	IOWR_OC_I2C_TXR(base, reg);
	IOWR_OC_I2C_CR(base, OC_I2C_CR_WR_MSK);
	I2CWaitTIP(base);

	//дһ����ʾ���ݳ��ȵ����ݽ�ȥ 2021/3/17/ccb
	IOWR_OC_I2C_TXR(base, num);
	IOWR_OC_I2C_CR(base, OC_I2C_CR_WR_MSK);
	I2CWaitTIP(base);

	// write data
	IOWR_OC_I2C_TXR(base, data>>8);
	IOWR_OC_I2C_CR(base, OC_I2C_CR_WR_MSK);
	I2CWaitTIP(base);

	// write data with STOP signal
	IOWR_OC_I2C_TXR(base, data & 0x00ff);
	IOWR_OC_I2C_CR(base, OC_I2C_CR_WR_MSK | OC_I2C_CR_STO_MSK);
	I2CWaitTIP(base);
}


uint8_t I2CReadOneReg(uint32_t base, uint8_t address, uint8_t reg, uint8_t num)
{
	// Wait for the completion of transfer
	I2CWaitTIP(base);

	// write address of I2C slave device
	// and generate START & WR command
	IOWR_OC_I2C_TXR(base, address<<1);
	IOWR_OC_I2C_CR(base, OC_I2C_CR_STA_MSK | OC_I2C_CR_WR_MSK);
	I2CWaitTIP(base);

	// write register address
	IOWR_OC_I2C_TXR(base, reg);
	IOWR_OC_I2C_CR(base, OC_I2C_CR_WR_MSK);
	I2CWaitTIP(base);

	//дһ����ʾ���ݳ��ȵ����ݽ�ȥ 2021/3/17/ccb
	IOWR_OC_I2C_TXR(base, num);
	IOWR_OC_I2C_CR(base, OC_I2C_CR_WR_MSK);
	I2CWaitTIP(base);

	// write address of I2C slave device
	// and RD command
	IOWR_OC_I2C_TXR(base, (address<<1)|0x01);
	IOWR_OC_I2C_CR(base, OC_I2C_CR_STA_MSK | OC_I2C_CR_WR_MSK);
	I2CWaitTIP(base);

	// Read data with STOP signal
	IOWR_OC_I2C_CR(base, OC_I2C_CR_RD_MSK | OC_I2C_CR_ACK_MSK | OC_I2C_CR_STO_MSK);
	I2CWaitTIP(base);
	return IORD_OC_I2C_RXR(base);
}


uint16_t I2CRead(uint32_t base, uint8_t address, uint8_t reg, uint8_t num)
{
	uint8_t temp = 0;
	uint8_t msb = 0;
	uint8_t lsb = 0;
	// Wait for the completion of transfer
	I2CWaitTIP(base);

	// write address of I2C slave device
	// and generate START & WR command
	IOWR_OC_I2C_TXR(base, address<<1);
	IOWR_OC_I2C_CR(base, OC_I2C_CR_STA_MSK | OC_I2C_CR_WR_MSK);
	I2CWaitTIP(base);

	// write register address
	IOWR_OC_I2C_TXR(base, reg);
	IOWR_OC_I2C_CR(base, OC_I2C_CR_WR_MSK);
	I2CWaitTIP(base);

	//дһ����ʾ���ݳ��ȵ����ݽ�ȥ 2021/3/17/ccb
	IOWR_OC_I2C_TXR(base, num);
	IOWR_OC_I2C_CR(base, OC_I2C_CR_WR_MSK);
	I2CWaitTIP(base);

	// write address of I2C slave device
	// and RD command
	temp = (address<<1) | 0x01;
	IOWR_OC_I2C_TXR(base, temp);
	IOWR_OC_I2C_CR(base, OC_I2C_CR_STA_MSK | OC_I2C_CR_WR_MSK);
	I2CWaitTIP(base);
	// Read data
	IOWR_OC_I2C_CR(base, OC_I2C_CR_RD_MSK);
	// | I2C_CR_ACK);
	I2CWaitTIP(base);
	msb = IORD_OC_I2C_RXR(base);

	// Read data with STOP signal
	IOWR_OC_I2C_CR(base, OC_I2C_CR_RD_MSK | OC_I2C_CR_ACK_MSK | OC_I2C_CR_STO_MSK);
	I2CWaitTIP(base);
	lsb = IORD_OC_I2C_RXR(base);

	return ((msb<<8)|lsb);
}

