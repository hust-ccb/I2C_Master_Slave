#ifndef __OC_I2C_H__
#define __OC_I2C_H__

#include "alt_types.h"
#include "stdint.h"

void InitI2C(uint32_t base, uint32_t freq, uint8_t IEN);
void I2CWriteOneReg(uint32_t base, uint8_t address, uint8_t reg, uint8_t num, uint8_t data);
void I2CWrite(uint32_t base, uint8_t address, uint8_t reg, uint8_t num, uint16_t data);
uint8_t I2CReadOneReg(uint32_t base, uint8_t address, uint8_t reg, uint8_t num);
uint16_t I2CRead(uint32_t base, uint8_t address, uint8_t reg, uint8_t num);

#endif /* __OC_I2C_H__ */
